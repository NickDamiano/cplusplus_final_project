#include "player.hpp"
#include <queue>


Player::Player()
{
    proximity_option1 = "player";
}
void Player::listOptions()
{
    // should list options arounnd player to do 
    
}

Space* Player::doStuff(std::queue<Space*>&inventory)
{

}