#include "space.hpp"

Space::Space()
{

}

Space::~Space()
{
    
}

string Space::get_proximity_option1()
{
    return proximity_option1;
}
string Space::get_proximity_option2()
{
    return proximity_option2;
}



